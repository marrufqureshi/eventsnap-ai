// Copies face-api model weights + browser bundle into /public so the browser can load them.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const pkg = path.join(root, 'node_modules', '@vladmandic', 'face-api');
const copy = (from, to) => { fs.mkdirSync(path.dirname(to), { recursive: true }); fs.cpSync(from, to, { recursive: true }); };
try {
  copy(path.join(pkg, 'model'), path.join(root, 'public', 'models'));
  copy(path.join(pkg, 'dist', 'face-api.js'), path.join(root, 'public', 'vendor', 'face-api.js'));
  console.log('face-api weights and bundle copied to /public');
} catch (e) {
  console.warn('Could not copy face-api assets:', e.message, '\nDownload /model and /dist/face-api.js from github.com/vladmandic/face-api into public/models and public/vendor.');
}
