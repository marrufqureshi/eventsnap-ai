import archiver from 'archiver';
import { Readable } from 'stream';
import { db, absPath, rateLimit, ip } from '@/lib/core';

export async function GET(req, { params }) {
  if (!rateLimit(`zip:${ip(req)}`, 5)) return new Response('Too many requests', { status: 429 });
  const a = await db.attendee.findUnique({ where: { galleryToken: params.token }, include: { matches: { include: { photo: true } } } });
  if (!a) return new Response('Not found', { status: 404 });
  const zip = archiver('zip', { store: true }); // JPEGs don't compress, so store them as-is
  const seen = new Set();
  for (const m of a.matches) {
    if (seen.has(m.photoId)) continue;
    seen.add(m.photoId);
    zip.file(absPath(m.photo.path), { name: `${seen.size}-${m.photo.filename}` });
  }
  zip.finalize();
  return new Response(Readable.toWeb(zip), {
    headers: { 'Content-Type': 'application/zip', 'Content-Disposition': 'attachment; filename="my-event-photos.zip"' },
  });
}
