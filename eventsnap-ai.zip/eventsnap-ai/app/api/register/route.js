import { NextResponse } from 'next/server';
import crypto from 'crypto';
import { db, saveFile, rateLimit, ip } from '@/lib/core';
import { runMatching } from '@/lib/matching';
import { notifyPending } from '@/lib/notify';

const err = (m, s = 400) => NextResponse.json({ error: m }, { status: s });

export async function POST(req) {
  if (!rateLimit(`reg:${ip(req)}`, 5)) return err('Too many attempts. Try again in a minute.', 429);
  const eventId = new URL(req.url).searchParams.get('event') || 'default';
  const fd = await req.formData();
  const name = String(fd.get('name') || '').trim();
  const phone = String(fd.get('phone') || '').replace(/[^\d+]/g, '');
  const email = String(fd.get('email') || '').trim();
  let embedding; try { embedding = JSON.parse(fd.get('embedding')); } catch {}
  const selfie = fd.get('selfie');

  if (fd.get('consent') !== 'true') return err('Consent is required to continue.');
  if (!name || !/^\+\d{8,15}$/.test(phone) || !/^\S+@\S+\.\S+$/.test(email)) return err('Check your name, phone number (with country code) and email.');
  if (!Array.isArray(embedding) || embedding.length !== 128 || !selfie?.size) return err('A clear selfie with one face is required.');

  await db.attendee.create({
    data: {
      eventId, name, phone, email, embedding: JSON.stringify(embedding), consentAt: new Date(),
      selfiePath: await saveFile('selfies', Buffer.from(await selfie.arrayBuffer())),
      galleryToken: crypto.randomBytes(24).toString('base64url'),
    },
  });
  // Late registrants: match against photos that were already uploaded.
  if (await db.eventPhoto.count({ where: { eventId } })) {
    await runMatching(eventId);
    if (process.env.AUTO_SEND === 'true') await notifyPending(eventId);
  }
  return NextResponse.json({ ok: true });
}
