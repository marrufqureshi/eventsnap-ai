import { NextResponse } from 'next/server';
import { db, isAdmin, makeSession, saveFile } from '@/lib/core';
import { runMatching, defaultThreshold } from '@/lib/matching';
import { deliver, notifyPending } from '@/lib/notify';

const json = (d, s = 200) => NextResponse.json(d, { status: s });
const eventOf = (req) => new URL(req.url).searchParams.get('event') || 'default';

// GET /api/admin/data?event=  -> attendees (+delivery logs), photo count, faces still unmatched
export async function GET(req, { params }) {
  if (!isAdmin()) return json({ error: 'Unauthorized' }, 401);
  if (params.action !== 'data') return json({ error: 'Not found' }, 404);
  const eventId = eventOf(req);
  const [attendees, photos] = await Promise.all([
    db.attendee.findMany({
      where: { eventId }, orderBy: { createdAt: 'desc' },
      include: { _count: { select: { matches: true } }, logs: { orderBy: { createdAt: 'desc' }, take: 4 } },
    }),
    db.eventPhoto.findMany({ where: { eventId }, orderBy: { createdAt: 'desc' }, include: { matches: { select: { faceIndex: true } } } }),
  ]);
  const unmatched = photos.map((p) => {
    const hit = new Set(p.matches.map((m) => m.faceIndex));
    return { id: p.id, faces: JSON.parse(p.faces).map((f, i) => ({ i, box: f.box })).filter((f) => !hit.has(f.i)) };
  }).filter((p) => p.faces.length).slice(0, 30);
  return json({ attendees: attendees.map(({ embedding, ...a }) => a), photoCount: photos.length, unmatched, threshold: defaultThreshold() });
}

export async function POST(req, { params }) {
  const { action } = params;
  if (action === 'login') {
    const { password } = await req.json().catch(() => ({}));
    if (!process.env.ADMIN_PASSWORD || password !== process.env.ADMIN_PASSWORD) return json({ error: 'Wrong password.' }, 401);
    const res = json({ ok: true });
    res.cookies.set('admin', makeSession(), { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 43200, path: '/' });
    return res;
  }
  if (!isAdmin()) return json({ error: 'Unauthorized' }, 401);
  const eventId = eventOf(req);

  if (action === 'upload') { // one photo + the faces the browser already detected in it
    const fd = await req.formData(); const file = fd.get('file');
    if (!file?.size) return json({ error: 'No file' }, 400);
    const p = await db.eventPhoto.create({
      data: { eventId, filename: file.name, faces: String(fd.get('faces') || '[]'), path: await saveFile('photos', Buffer.from(await file.arrayBuffer()), file.name.split('.').pop()) },
    });
    return json({ id: p.id });
  }

  const body = await req.json().catch(() => ({}));
  if (action === 'match') {
    const r = await runMatching(eventId, Number(body.threshold) || defaultThreshold());
    return json({ ...r, notified: body.notify ? await notifyPending(eventId) : 0 });
  }
  if (action === 'assign') { // manual tag: face #faceIndex in photo -> attendee
    const { photoId, faceIndex, attendeeId } = body;
    await db.photoMatch.upsert({
      where: { photoId_faceIndex: { photoId, faceIndex } },
      create: { photoId, faceIndex, attendeeId, distance: 0, source: 'manual' },
      update: { attendeeId, distance: 0, source: 'manual' },
    });
    return json({ ok: true });
  }
  if (action === 'resend') {
    const a = await db.attendee.findUnique({ where: { id: body.attendeeId } });
    return a ? json(await deliver(a, body.channel === 'email' ? 'email' : 'whatsapp')) : json({ error: 'Not found' }, 404);
  }
  return json({ error: 'Not found' }, 404);
}
