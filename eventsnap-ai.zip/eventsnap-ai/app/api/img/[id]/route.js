import { db, isAdmin, readFile } from '@/lib/core';

// Private file access: a photo is served only with a valid gallery token that matches it, or an admin session.
export async function GET(req, { params }) {
  const q = new URL(req.url).searchParams;
  const admin = isAdmin();
  let rel;
  if (q.get('kind') === 'selfie') {
    rel = admin ? (await db.attendee.findUnique({ where: { id: params.id } }))?.selfiePath : null;
  } else {
    const where = admin ? { id: params.id } : { id: params.id, matches: { some: { attendee: { galleryToken: q.get('t') || '-' } } } };
    rel = (await db.eventPhoto.findFirst({ where }))?.path;
  }
  if (!rel) return new Response('Not found', { status: 404 });
  const ext = rel.split('.').pop();
  return new Response(await readFile(rel), {
    headers: {
      'Content-Type': ext === 'png' ? 'image/png' : ext === 'webp' ? 'image/webp' : 'image/jpeg',
      'Cache-Control': 'private, max-age=3600',
      ...(q.get('dl') ? { 'Content-Disposition': `attachment; filename="photo-${params.id}.${ext}"` } : {}),
    },
  });
}
