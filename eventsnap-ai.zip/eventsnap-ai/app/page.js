import Link from 'next/link';
export default function Home() {
  const a = 'text-teal-700 underline';
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">EventSnap AI</h1>
      <p className="mt-2"><Link className={a} href="/admin">Admin dashboard</Link> · <Link className={a} href="/e/default">Attendee page</Link></p>
    </main>
  );
}
