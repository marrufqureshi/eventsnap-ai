import { notFound } from 'next/navigation';
import { db } from '@/lib/core';

export const dynamic = 'force-dynamic';
export const metadata = { title: 'Your photos', robots: { index: false, follow: false }, referrer: 'no-referrer' };

export default async function Gallery({ params }) {
  const a = await db.attendee.findUnique({ where: { galleryToken: params.token }, include: { matches: { select: { photoId: true } } } });
  if (!a) notFound();
  const ids = [...new Set(a.matches.map((m) => m.photoId))];
  const t = params.token;
  return (
    <main className="mx-auto max-w-3xl p-4">
      <h1 className="text-2xl font-bold">{a.name.split(' ')[0]}, here are your photos</h1>
      <p className="mt-1 text-sm text-slate-600">{ids.length} photo{ids.length === 1 ? '' : 's'}. This link is private, so only share it with people you trust.</p>
      {ids.length === 0 && <p className="mt-6 text-slate-600">Your photos aren't ready yet. Check back soon.</p>}
      {ids.length > 0 && <a href={`/api/zip/${t}`} className="mt-3 inline-block rounded-lg bg-teal-700 px-4 py-2.5 font-medium text-white">Download all as .zip</a>}
      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
        {ids.map((id) => (
          <figure key={id} className="relative">
            <img src={`/api/img/${id}?t=${t}`} alt="" loading="lazy" className="aspect-square w-full rounded-lg object-cover" />
            <a href={`/api/img/${id}?t=${t}&dl=1`} className="absolute bottom-1 right-1 rounded bg-black/65 px-2 py-1 text-xs text-white">Save</a>
          </figure>
        ))}
      </div>
    </main>
  );
}
