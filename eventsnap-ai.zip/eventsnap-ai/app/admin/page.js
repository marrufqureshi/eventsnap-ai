'use client';
import { useCallback, useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { detectFaces, fileToImage } from '@/lib/faceClient';

const api = async (path, opts) => { const r = await fetch(`/api/admin/${path}`, opts); return { ok: r.ok, status: r.status, data: await r.json().catch(() => ({})) }; };
const post = (path, body) => api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
const badge = { sent: 'bg-green-100 text-green-800', failed: 'bg-red-100 text-red-800', pending: 'bg-amber-100 text-amber-800' };
const card = 'rounded-xl bg-white p-4 ring-1 ring-slate-200';
const primary = 'rounded-lg bg-teal-700 px-4 py-2 font-medium text-white';

export default function Admin() {
  const [authed, setAuthed] = useState(null);
  const [pw, setPw] = useState('');
  const [event, setEvent] = useState('default');
  const [d, setD] = useState(null);
  const [prog, setProg] = useState(null);
  const [th, setTh] = useState('');
  const [notify, setNotify] = useState(true);
  const [msg, setMsg] = useState('');
  const [qr, setQr] = useState('');

  const load = useCallback(async () => {
    const r = await api(`data?event=${encodeURIComponent(event)}`);
    if (r.status === 401) return setAuthed(false);
    setAuthed(true); setD(r.data);
  }, [event]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => { QRCode.toDataURL(`${location.origin}/e/${encodeURIComponent(event)}`, { width: 320, margin: 1 }).then(setQr); }, [event]);

  async function upload(files) {
    const list = [...files].filter((f) => f.type.startsWith('image/'));
    if (!list.length) return;
    setProg({ done: 0, total: list.length, failed: 0 });
    let next = 0;
    const worker = async () => {
      while (next < list.length) {
        const file = list[next++];
        try {
          const faces = await detectFaces(await fileToImage(file)); // detection + embedding happen in this browser
          const fd = new FormData(); fd.append('file', file); fd.append('faces', JSON.stringify(faces));
          if (!(await api(`upload?event=${encodeURIComponent(event)}`, { method: 'POST', body: fd })).ok) throw new Error('upload');
        } catch { setProg((p) => ({ ...p, failed: p.failed + 1 })); }
        setProg((p) => ({ ...p, done: p.done + 1 }));
      }
    };
    await Promise.all([worker(), worker()]);
    setMsg('Upload finished. Run matching to sort the photos.'); load();
  }
  async function runMatch() {
    setMsg('Matching…');
    const r = await post(`match?event=${encodeURIComponent(event)}`, { threshold: th, notify });
    setMsg(r.ok ? `${r.data.matches} faces matched, ${r.data.notified} attendees notified.` : r.data.error); load();
  }
  const assign = async (photoId, faceIndex, attendeeId) => { await post('assign', { photoId, faceIndex, attendeeId }); load(); };

  if (authed === null) return <p className="p-6">Loading…</p>;
  if (!authed) return (
    <form onSubmit={async (e) => { e.preventDefault(); const r = await post('login', { password: pw }); r.ok ? load() : setMsg(r.data.error); }} className="mx-auto mt-24 max-w-xs space-y-3 p-4">
      <h1 className="text-xl font-bold">EventSnap admin</h1>
      <input type="password" placeholder="Password" value={pw} onChange={(e) => setPw(e.target.value)} className="w-full rounded-lg border px-3 py-2" />
      <button className={`${primary} w-full`}>Sign in</button>
      <p className="text-sm text-red-700">{msg}</p>
    </form>
  );

  return (
    <main className="mx-auto max-w-5xl space-y-4 p-4">
      <header className="flex flex-wrap items-center gap-3">
        <h1 className="text-xl font-bold">EventSnap AI admin</h1>
        <label className="text-sm">Event ID <input value={event} onChange={(e) => setEvent(e.target.value.replace(/[^\w-]/g, ''))} className="ml-1 rounded border px-2 py-1" /></label>
      </header>

      <section className={`${card} flex items-center gap-4`}>
        {qr && <img src={qr} alt="Attendee QR code" className="h-28 w-28" />}
        <div className="text-sm">Attendees scan this to register at <b>/e/{event}</b><br /><a className="text-teal-700 underline" href={qr} download={`${event}-qr.png`}>Download QR</a></div>
      </section>

      <section className={card} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); upload(e.dataTransfer.files); }}>
        <label className="block cursor-pointer rounded-lg border-2 border-dashed border-slate-300 p-8 text-center text-slate-600">
          Drop event photos here or tap to choose ({d?.photoCount ?? 0} uploaded)
          <input type="file" multiple accept="image/*" hidden onChange={(e) => upload(e.target.files)} />
        </label>
        {prog && (
          <div className="mt-3">
            <div className="h-2 rounded bg-slate-200"><div className="h-2 rounded bg-teal-700" style={{ width: `${(prog.done / prog.total) * 100}%` }} /></div>
            <p className="mt-1 text-xs text-slate-600">{prog.done} of {prog.total} processed, {prog.failed} failed</p>
          </div>
        )}
      </section>

      <section className={`${card} flex flex-wrap items-center gap-3`}>
        <label className="text-sm">Match threshold <input value={th} onChange={(e) => setTh(e.target.value)} placeholder={String(d?.threshold ?? 0.5)} className="w-16 rounded border px-2 py-1" /></label>
        <label className="text-sm"><input type="checkbox" checked={notify} onChange={(e) => setNotify(e.target.checked)} /> Send links after matching</label>
        <button onClick={runMatch} className={primary}>Run matching</button>
        <span className="text-sm text-slate-600">{msg}</span>
      </section>

      <section className={`${card} overflow-x-auto`}>
        <h2 className="mb-2 font-semibold">Attendees ({d.attendees.length})</h2>
        <table className="w-full text-left text-sm">
          <thead className="text-slate-500"><tr><th>Name</th><th>Faces</th><th>WhatsApp</th><th>Email</th></tr></thead>
          <tbody>
            {d.attendees.map((a) => {
              const st = (ch) => a.logs.find((l) => l.channel === ch)?.status || 'pending';
              return (
                <tr key={a.id} className="border-t align-top">
                  <td className="py-2"><a className="font-medium text-teal-700 underline" href={`/g/${a.galleryToken}`} target="_blank">{a.name}</a><div className="text-xs text-slate-500">{a.phone} · {a.email}</div></td>
                  <td>{a._count.matches}</td>
                  {['whatsapp', 'email'].map((ch) => (
                    <td key={ch}><span className={`rounded px-2 py-0.5 text-xs ${badge[st(ch)]}`}>{st(ch)}</span>{' '}
                      <button className="text-xs underline" onClick={() => post('resend', { attendeeId: a.id, channel: ch }).then(load)}>Resend</button></td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>

      {d.unmatched.length > 0 && (
        <section className={card}>
          <h2 className="font-semibold">Unmatched faces</h2>
          <p className="mb-3 text-sm text-slate-600">Pick who each boxed face belongs to, then run matching with "Send links" on to deliver.</p>
          <div className="grid gap-4 sm:grid-cols-2">
            {d.unmatched.map((p) => (
              <div key={p.id}>
                <div className="relative">
                  <img src={`/api/img/${p.id}`} alt="" loading="lazy" className="w-full rounded-lg" />
                  {p.faces.map((f) => <div key={f.i} className="absolute border-2 border-amber-400 text-xs font-bold text-amber-300" style={{ left: `${f.box[0] * 100}%`, top: `${f.box[1] * 100}%`, width: `${f.box[2] * 100}%`, height: `${f.box[3] * 100}%` }}>{f.i + 1}</div>)}
                </div>
                {p.faces.map((f) => (
                  <select key={f.i} defaultValue="" onChange={(e) => e.target.value && assign(p.id, f.i, e.target.value)} className="mt-1 w-full rounded border px-2 py-1 text-sm">
                    <option value="">Face {f.i + 1}: assign to…</option>
                    {d.attendees.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
                  </select>
                ))}
              </div>
            ))}
          </div>
        </section>
      )}
    </main>
  );
}
