'use client';
import { useEffect, useRef, useState } from 'react';
import { detectFaces, fileToImage, loadFaceApi } from '@/lib/faceClient';

const inp = 'w-full rounded-lg border border-slate-300 bg-white px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-teal-600';
const btn = 'flex-1 rounded-lg bg-teal-700 px-4 py-2.5 text-center font-medium text-white disabled:opacity-50';
const btn2 = 'flex-1 cursor-pointer rounded-lg border border-slate-300 bg-white px-4 py-2.5 text-center font-medium';
const corners = ['top-3 left-3 border-t-2 border-l-2', 'top-3 right-3 border-t-2 border-r-2', 'bottom-3 left-3 border-b-2 border-l-2', 'bottom-3 right-3 border-b-2 border-r-2'];

export default function Join({ params }) {
  const [f, setF] = useState({ name: '', cc: '+91', phone: '', email: '', consent: false });
  const [selfie, setSelfie] = useState(null); // { blob, url, embedding }
  const [camOn, setCamOn] = useState(false);
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const video = useRef();
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });
  const stop = () => video.current?.srcObject?.getTracks().forEach((t) => t.stop());

  useEffect(() => { loadFaceApi().catch((e) => setMsg(e.message)); return stop; }, []);

  async function startCam() {
    setMsg('');
    try {
      video.current.srcObject = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user', width: 720 }, audio: false });
      setSelfie(null); setCamOn(true);
    } catch { setMsg('Camera is blocked or needs HTTPS. Allow camera access, or upload a photo instead.'); }
  }
  async function check(source, blob) {
    setBusy(true); setMsg('Checking your photo…');
    try {
      const faces = await detectFaces(source);
      if (faces.length !== 1) throw new Error(faces.length ? 'More than one face found. Use a photo of only you.' : 'No face found. Face the camera in good light.');
      setSelfie({ blob, url: URL.createObjectURL(blob), embedding: faces[0].descriptor }); setMsg('');
    } catch (e) { setMsg(e.message); } finally { setBusy(false); }
  }
  async function snap() {
    const v = video.current, c = document.createElement('canvas');
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext('2d').drawImage(v, 0, 0);
    const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.9));
    stop(); setCamOn(false); await check(c, blob);
  }
  async function pick(e) { const file = e.target.files[0]; if (file) await check(await fileToImage(file), file); }

  async function submit(e) {
    e.preventDefault();
    if (!selfie) return setMsg('Add a selfie to continue.');
    setBusy(true); setMsg('');
    const fd = new FormData();
    Object.entries({ name: f.name, phone: f.cc + f.phone, email: f.email, consent: f.consent, embedding: JSON.stringify(selfie.embedding) }).forEach(([k, v]) => fd.append(k, v));
    fd.append('selfie', selfie.blob, 'selfie.jpg');
    const r = await fetch(`/api/register?event=${encodeURIComponent(params.eventId)}`, { method: 'POST', body: fd });
    const j = await r.json().catch(() => ({}));
    setBusy(false);
    r.ok ? setDone(true) : setMsg(j.error || 'Something went wrong. Try again.');
  }

  if (done) return (
    <main className="grid min-h-screen place-items-center p-6 text-center">
      <div><h1 className="text-2xl font-bold">You're on the list</h1><p className="mt-2 text-slate-600">We'll send your private photo link on WhatsApp as soon as your photos are sorted.</p></div>
    </main>
  );

  return (
    <main className="mx-auto max-w-md p-4">
      <h1 className="text-2xl font-bold">Find yourself in the event photos</h1>
      <p className="mt-1 text-sm text-slate-600">Take a selfie and we'll send you every photo you're in.</p>
      <form onSubmit={submit} className="mt-4 space-y-3">
        <div className="relative grid aspect-[3/4] place-items-center overflow-hidden rounded-2xl bg-slate-900">
          <video ref={video} autoPlay playsInline muted className={`h-full w-full -scale-x-100 object-cover ${camOn ? '' : 'hidden'}`} />
          {selfie && !camOn && <img src={selfie.url} alt="Your selfie" className="h-full w-full object-cover" />}
          {!selfie && !camOn && <p className="text-sm text-slate-400">Your selfie appears here</p>}
          {corners.map((c) => <i key={c} className={`absolute h-7 w-7 border-white/80 ${c}`} />)}
        </div>
        <div className="flex gap-2">
          {camOn ? <button type="button" onClick={snap} className={btn}>Capture</button>
            : <button type="button" onClick={startCam} disabled={busy} className={btn}>{selfie ? 'Retake selfie' : 'Open camera'}</button>}
          <label className={btn2}>Upload a photo instead<input type="file" accept="image/*" hidden onChange={pick} /></label>
        </div>
        <input required placeholder="Full name" autoComplete="name" value={f.name} onChange={set('name')} className={inp} />
        <div className="flex gap-2">
          <input aria-label="Country code" inputMode="tel" value={f.cc} onChange={set('cc')} className={`${inp} w-20`} />
          <input required placeholder="Phone number" inputMode="tel" autoComplete="tel-national" value={f.phone} onChange={set('phone')} className={inp} />
        </div>
        <input required type="email" placeholder="Email" autoComplete="email" value={f.email} onChange={set('email')} className={inp} />
        <label className="flex gap-2 text-sm text-slate-700">
          <input type="checkbox" required checked={f.consent} onChange={set('consent')} className="mt-1" />
          I agree that my selfie is used for face matching at this event and that my photos are sent to me by WhatsApp and email.
        </label>
        {msg && <p className="text-sm text-red-700" role="alert">{msg}</p>}
        <div className="flex"><button disabled={busy} className={btn}>{busy ? 'Working…' : 'Join and get my photos'}</button></div>
      </form>
    </main>
  );
}
