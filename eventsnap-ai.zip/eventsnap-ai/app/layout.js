import './globals.css';
export const metadata = { title: 'EventSnap AI' };
export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-stone-50 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
